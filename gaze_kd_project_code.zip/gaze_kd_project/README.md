# Gaze regression with knowledge distillation

PyTorch code for 2D gaze $(g_x, g_y)$ from face images. Trains a teacher, a compact student, and an optional KD student. Works with CSV paths + labels or with MPIIGaze `Data/Normalized` `.mat` files.

## Setup

Use Python 3.10+ if you can. Install the right PyTorch wheel first ([pytorch.org](https://pytorch.org)), then:

```bash
cd gaze_kd_project
pip install -r requirements.txt
```

## Synthetic sanity check

Generates fake faces so you can verify the training loop without downloading anything large:

```bash
python scripts/generate_synthetic_gaze_dataset.py --out_root data/synthetic
python train_teacher.py --teacher_arch mobilenet_v2 \
  --train_csv data/synthetic/train.csv --val_csv data/synthetic/val.csv \
  --data_root data/synthetic --checkpoint checkpoints/teacher_best.pt
python train_student.py --train_csv data/synthetic/train.csv --val_csv data/synthetic/val.csv \
  --data_root data/synthetic --checkpoint checkpoints/student_baseline_best.pt
python train_kd.py --teacher_ckpt checkpoints/teacher_best.pt \
  --train_csv data/synthetic/train.csv --val_csv data/synthetic/val.csv \
  --data_root data/synthetic --checkpoint checkpoints/student_kd_best.pt
```

`train_teacher.py` defaults to `resnet18`; MobileNet teachers are usually a better fit for small gaze datasets. On GPU, add `--amp` if you want.

## MPIIGaze

You need the official dataset (normalized eye patches under `Data/Normalized`). This repo does not ship it.

Example (Unix shell):

```bash
export MPI_ROOT=/path/to/MPIIGaze
export MPI_VAL=14,15
python train_teacher.py --dataset mpiigaze --mpi_root "$MPI_ROOT" --mpi_val_persons "$MPI_VAL" \
  --teacher_arch mobilenet_v3_small --checkpoint checkpoints/teacher_mpi.pt \
  --epochs 20 --amp --metrics_csv runs/m_teacher.csv
```

Use the same `--dataset mpiigaze` / `--mpi_root` / `--mpi_val_persons` pattern for `train_student.py`, `train_kd.py`, and `evaluate.py`. Drop `--csv` when using the built-in MPII reader.

`scripts/inspect_mpiigaze_layout.py` prints what it finds under a given root—useful if paths look wrong.

## Evaluation

```bash
python evaluate.py --model teacher --checkpoint checkpoints/teacher_best.pt \
  --csv data/synthetic/val.csv --data_root data/synthetic --export_json runs/eval_teacher.json
```

For MPIIGaze, swap in `--dataset mpiigaze` and the `mpi_*` flags instead of `--csv`. Student runs need `--student_arch gaze_micro` (or whatever you trained) if the checkpoint metadata is missing.

## Plots + LaTeX

```bash
python scripts/build_eval_summary.py --out runs/summary.json \
  --teacher runs/eval_teacher.json --student_baseline runs/eval_student.json --student_kd runs/eval_kd.json
python scripts/make_paper_figures.py --out_dir paper/figures --summary runs/summary.json \
  --metrics_teacher runs/m_teacher.csv --metrics_student runs/m_student.csv --metrics_kd runs/m_kd.csv
```

Output is PNG (default 300 dpi). `paper/report.tex` targets `pdflatex` from inside `paper/`.

## File map

| Item | Purpose |
|------|---------|
| `train_teacher.py`, `train_student.py`, `train_kd.py` | Training entry points |
| `evaluate.py` | Metrics, latency, JSON dump |
| `config.py`, `utils.py` | Hyperparameters, loops, checkpoints |
| `models/` | Teacher / student constructors |
| `datasets/` | `GazeDataset` + MPIIGaze loader + CLI wiring |
| `scripts/` | Synthetic data, JSON merge, matplotlib figures |

MPIIGaze is from Zhang et al., CVPR 2015; use it under their license.
